#import "Person.h"

NS_ASSUME_NONNULL_BEGIN

@interface Orders : NSObject

@property(nonatomic, copy) NSString *PassengerName;
@property(nonatomic, copy) NSString *TrainNo;
@property(nonatomic, assign) NSDate *StartDate;
@property(nonatomic, assign) NSDate *EndDate;
@property(nonatomic, copy) NSNumber *SeatNo;

- (instancetype)initOrder:(NSString *) PassengerName trainnumber:(NSString *) TrainNo startdate:(nonnull NSDate *) StartDate enddate:(nonnull NSDate *) EndDate seatnumber:(NSNumber *) SeatNo;


@end

@interface Passenger : Person
// @property 属性
@property(nonatomic, assign) bool if_18; // 是否年满 18 岁

@property(nonatomic, assign) NSMutableArray *HistoryOrders; // 历史订单 （数组）
@property(nonatomic, assign) NSMutableArray *NoTravelOrder  // 未出行订单 （数组）

    // Function 方法
- (void)book : (Orders *)book_order; // 去订票
- (void)check: (Orders *)check_order; // 去检票
@end

NS_ASSUME_NONNULL_END
