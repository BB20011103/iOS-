#import "Passenger.h"


@implementation Orders

- (instancetype)initOrder:(NSString *) PassengerName trainnumber:(NSString *) TrainNo startdate:(nonnull NSDate *) StartDate enddate:(nonnull NSDate *) EndDate seatnumber:(NSNumber *) SeatNo;
        if(self = [super init]){
        [self createOrder:PassengerName trainnumber:TrainNo startdate:StartDate enddate:EndDate seatnumber:SeatNo];
    }
    return self;

- (void)createOrder:(NSString *) PassengerName trainnumber:(NSString *) TrainNo startdate:(nonnull NSDate *) StartDate enddate:(nonnull NSDate *) EndDate seatnumber:(NSNumber *) SeatNo{
    
    self.PassengerName=PassengerName;
    self.TrainNumber=TrainNumber;
    self.StartTime=StartTime;
    self.EndTime=EndTime;
    self.SeatNumber=SeatNumber;
}

@end

@implementation Passenger

- (bool) if_18{
    return self.age >= 18;
}

- (void) book:(Orders *) book_order{
    [self.NoTravelOrder addObject:book_order];
}

- (void) check:(Orders *) check_order{
    [self.HistoryOrder addObject:check_order];
    [self.NoTravelOrder removeObject:order];
}

@end
